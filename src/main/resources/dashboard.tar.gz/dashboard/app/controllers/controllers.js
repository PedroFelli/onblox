
app.controller('loginCtrl', function($scope, $location) {
      $scope.submit = function(){
          if($scope.name == 'admin' && $scope.password == 'admin'){
              $location.path('/home');
              console.log('login')
          } else {
              console.log('Senha ou login errado')
          }
          
      };
  });




  app.controller('tableCtrl', function($scope){
    $scope.produtos =[
	    {"id": 1, "name": "pedro", "quantidade": 11, "preco": 21},
	    {"id": 2, "name": "teste2", "quantidade": 2, "preco":  2},
	    {"id": 3, "name": "teste3", "quantidade": 31, "preco": 31},
	    {"id": 4, "name": "teste4", "quantidade": 41, "preco": 41}
    ];
  });